import loginStore from '@/mobx/login'
import homeStore from '@/mobx/home'

export default {
  loginStore,
  homeStore,
}


