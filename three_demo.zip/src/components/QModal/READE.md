## QModal 公共按钮组件

```javascript

    import QModal from '@@@/QModal'

    /**
		 * data 参数
     * 
     * @param {open} { String } 展示隐藏
		 * @param {setOpen} { Object } 控制在那还是
		 * @param {className} { String } className
     * 
     * @param antd 所有属性
    */

    <QModal
      color="#000"
      fontSize="14"
      style={{}}
      className=""
      type=""
    />

```
.ant-space-item {
  
}