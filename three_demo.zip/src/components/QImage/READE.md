## QButton 公共按钮组件

```javascript

    import QImage from '@@@/QImage'

    /**
		 * data 参数
     * 
     * @param {src} { String } 颜色
		 * @param {style} { Object } 阴影
		 * @param {className} { String } className
     * 
     * @param antd 所有属性
    */

    <QIcon
      color="#000"
      fontSize="14"
      style={{}}
      className=""
      type=""
    />

```
.ant-space-item {
  
}