import { history } from 'umi';
import request from '@/utils/request';

export default {
  // 名字 必须唯一, 跟目录名起
  namespace: 'list',

  state: {
  },

  reducers: {
  },

  effects: {
  }
};
