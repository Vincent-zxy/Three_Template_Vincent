import { history } from 'umi'
import request from '@/utils/request'

export default {
  namespace: 'login',
  state: {
  },
  reducers: {
  },
  effects: {
  },
}
