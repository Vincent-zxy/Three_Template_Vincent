import _ from 'lodash'
import request from '@/utils/request'

export default {
  namespace: 'animation',

  state: {
  },

  reducers: {
  },

  effects: {
  },
}
