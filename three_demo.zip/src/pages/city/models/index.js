import _ from 'lodash'
import request from '@/utils/request'

export default {
  namespace: 'city',

  state: {
  },

  reducers: {
  },

  effects: {
  },
}
