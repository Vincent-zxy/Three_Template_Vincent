import React from 'react'
import { Form, Input } from 'antd'

export default function MyForm (props) {
  return (
    <Form>
      <Form.Item
        label="小白"
      >
        <Input />
      </Form.Item>
    </Form>
  )
}
