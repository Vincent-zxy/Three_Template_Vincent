import _ from 'lodash'
import request from '@/utils/request'

export default {
  namespace: 'move',
  state: {
  },
  reducers: {
  },
  effects: {
  },
}
